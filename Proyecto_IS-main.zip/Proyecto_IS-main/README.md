# Proyecto_IS
Proyecto de Ingenieria de software

El siguiente proyecto busca implementar un sistema para organizar una empresa y sus requerimientos  mediante un backend en java y manejo de bases de datos

¿ Porque Java?
utilizamos Java porque es un lenguaje multiplataforma, además es un lenguaje robusto 
¿Porque es importante el correcto manejo de la base de datos?
Facilita tener los datos agrupados en un solo lugar además de mejorar la organización del proyecto
