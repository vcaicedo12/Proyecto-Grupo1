package com.zetcode.modelo;

import javax.persistence.Entity;

import javax.persistence.Table;



@Entity
@Table(name = "users")
public class AnalisisP {

    

    public AnalisisP() {}

    public void analizar(){

    }
    public void asignarSt(){

    }
    public void asignarProg(){

    }
    public void determinar(){

    }
    public void otorgar(){

    }
}