package com.zetcode.modelo;

import javax.persistence.Entity;

import javax.persistence.Table;


@Entity
@Table(name = "users")
public class Asistente {

    public Asistente() {}

    public void recibir() {
    
    }

    public void devolver() {
        
    }

    public void asignar() {
        
    }

    public void facturar() {

    }

    
}