package com.zetcode.modelo;

import javax.persistence.Entity;

import javax.persistence.Table;

@Entity
@Table(name = "users")
public class RevisionSoft {


    public RevisionSoft() {}

   public void resolver(){

   }
   public void enviarInf(){

   }

}
