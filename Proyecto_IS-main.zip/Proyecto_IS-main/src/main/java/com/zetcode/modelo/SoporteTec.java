package com.zetcode.modelo;

import javax.persistence.Entity;

import javax.persistence.Table;


@Entity
@Table(name = "users")
public class SoporteTec {

    public SoporteTec() {}

    public void analizar(){

    }
    public void cotizar(){

    }
    public void resolver(){

    }
}